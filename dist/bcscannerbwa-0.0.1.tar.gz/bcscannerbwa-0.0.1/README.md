# BCscannerBWA
 
